export const ADD_COURSE = "ADD_COURSE";
