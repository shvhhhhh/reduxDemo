import Home from "./componants/home/home";
import AddCourse from "./componants/addCourse/addCourse";
export default [
  { path: "/", component: Home },
  { path: "/addCourse", component: AddCourse }
];
