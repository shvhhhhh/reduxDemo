import React, { Component } from "react";
import AddFrom from "../addForm/addForm";
import addCourse from "../../redux/actions/addCourse";
import { connect } from "react-redux";
class AddCourse extends Component {
  constructor(props: any) {
    super(props);
  }
  render() {
    return <AddFrom />;
  }
}

export default connect(
  null,
  { addCourse }
);
