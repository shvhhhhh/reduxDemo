import React, { Component } from "react";
import "./style.css";
export default class AddForm extends Component {
  constructor(props: any) {
    super(props);
    this.state = { a: "a" };
  }
  render() {
    return (
      <div className='form-container'>
        <h1>Add</h1>
        <form>
          <div className='form-group'>
            <label>Title</label>
            <input
              name={"title"}
              placeholder={"Title of the course"}
              className={"form-control"}
              value=''
            />
          </div>
          <div className='form-group'>
            <label>Author</label>
            <select name='author' className='form-control'>
              <option value=''></option>
              <option value='Deepak kumar'>Deepak kumar</option>
              <option value='Shubham bali'>Shubham bali</option>
              <option value='Pardeep kumar'>Pardeep kumar</option>
            </select>
          </div>
          <div className='form-group'>
            <label>Category</label>
            <input
              name='category'
              placeholder='Category of the course'
              className='form-control'
              value=''
            />
          </div>
          <div className='form-group'>
            <label>Length</label>
            <input
              name='length'
              placeholder='Length of course'
              className='form-control'
              value=''
            />
          </div>
        </form>
        <div className='form-btn-container'>
          <button className='form-btn submit-btn'>
            <i className='fa fa-paper-plane-o' aria-hidden='true'></i> Submit
          </button>
          <button className='form-btn'>Clear Values</button>
          <button className='form-btn'>Cancel</button>
        </div>
      </div>
    );
  }
}
