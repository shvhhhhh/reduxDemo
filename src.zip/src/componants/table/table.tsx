import React, { Component } from "react";
import "./style.css";
export default class Table extends Component {
  constructor(props: any) {
    super(props);
  }
  render() {
    return (
      <table className='table'>
        <thead>
          <tr>
            <th>Title</th>
            <th>Length</th>
            <th>Category</th>
            <th>Author</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td className='title'>Clean Code: Writing Code for Humans</td>
            <td>3:10</td>
            <td>Software Practices</td>
            <td>Deepak kumar</td>
          </tr>
          <tr>
            <td className='title'>Web Component Fundamentals</td>
            <td>5:10</td>
            <td>HTML5</td>
            <td>Shubham bali</td>
          </tr>
          <tr>
            <td className='title'>
              Architecting Applications for the Real World
            </td>
            <td>2:35</td>
            <td>Software Architecture</td>
            <td>Pardeep kumar</td>
          </tr>
        </tbody>
      </table>
    );
  }
}
