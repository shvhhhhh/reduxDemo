import React, { Component } from "react";
import ButtonGroup from "../buttonGroup/buttonGroup";
import Table from "../table/table";
export default class Home extends Component {
  constructor(props: any) {
    super(props);
  }
  render() {
    return (
      <div>
        <h1>Courses</h1>
        <ButtonGroup />
        <Table />
      </div>
    );
  }
}
